---
layout: default
title: Resume
---

# Resume

[Download PDF](pdf/Jillian_Weiss_Resume.pdf)

- **Education**: MS in Biotechnology, BS in Bioengineering
- **Skills**: Equity modeling, data analysis, R, Python, financial writing
- **Experience**: Biotech equity research internship, lab analyst
