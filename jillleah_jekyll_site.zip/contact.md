---
layout: default
title: Contact
---

# Contact

- Email: [jillian@email.com](mailto:jillian@email.com)
- LinkedIn: [linkedin.com/in/jillianweiss](https://linkedin.com/in/jillianweiss)
